#ifndef __CH32YYXX_FSMC_H_
#define __CH32YYXX_FSMC_H_

#if defined(CH32V30x) || defined(CH32V30x_C)
#include "ch32v30x_fsmc.h"
#endif

#endif /* __CH32YYXX_FSMC_H_ */