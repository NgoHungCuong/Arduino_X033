#if defined(CH32V30x) || defined(CH32V30x_C)
#include "ch32v30x_fsmc.c"
#endif