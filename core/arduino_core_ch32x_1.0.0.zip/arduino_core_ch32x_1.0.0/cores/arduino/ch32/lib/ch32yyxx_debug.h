#ifndef _CH32YYXX_DEBUG_H_
#define _CH32YYXX_DEBUG_H_

#include "debug.h"


#endif /*   _CH32YYXX_ADC_H_ */